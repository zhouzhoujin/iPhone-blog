# library

## 移动端拖动的实现


[demo][1] （请在移动端打开或者模拟移动端打开）

手机请扫

![drag demo 地址二维码][2]

PC端有`drag`事件的存在，而移动端不支持，此处实现在移动端的拖动操作

具体内容请[移步][3]


  [1]: https://dclcats.github.io/library/examples/index.html
  [2]: ./drag/images/1502175937.png "drag demo 地址二维码"
  [3]: https://github.com/dclcats/library/tree/master/drag